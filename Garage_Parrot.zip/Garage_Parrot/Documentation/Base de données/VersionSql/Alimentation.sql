INSERT INTO annonce (brand, model, description, year, mileage, fuel_type, transmission, price, img_path1, img_path2, img_path3, img_path4, img_path5) VALUES
(
    'Renault', 
    'Clio', 
    '\r\n        Lorem ipsum dolor sit amet, \r\n        \r\n        consectetur adipiscing elit. Phasellus ut blandit enim. \r\n        Donec sagittis porttitor malesuada. Proin posuere ultrices mauris, \r\n        a feugiat nisl vehicula sit amet. Suspendisse quis imperdiet diam.\r\n        \r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        \r\n        eget auctor nibh. Praesent sed nunc et nibh consectetur mattis. Etiam eu congue lectus, in lobortis ex. Cras maximus magna nec tempor hendrerit. Proin id accumsan justo, ut hendrerit massa. Sed eu sem turpis.\r\n        Aliquam sagittis, mauris at tristique placerat, libero est molestie nunc, sit amet rhoncus ligula urna vitae lectus. Duis vel ipsum pharetra, sodales justo sed, tincidunt leo. Fusce gravida porta sem, quis pulvinar odio ultrices id. \r\n        ', 
    2017, 
    25765, 
    'Diesel', 
    'Manuel', 
    '7500', 
    'sources/annonces/renault1.jpg', 
    'sources/annonces/renault2.jpg', 
    'sources/annonces/renault3.jpg', 
    '', 
    ''
),
(
    'Ferrari', 
    'California', 
    '\r\n        Lorem ipsum dolor sit amet, \r\n        \r\n        consectetur adipiscing elit. Phasellus ut blandit enim. \r\n        Donec sagittis porttitor malesuada. Proin posuere ultrices mauris, \r\n        a feugiat nisl vehicula sit amet. Suspendisse quis imperdiet diam.\r\n        \r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        \r\n        eget auctor nibh. Praesent sed nunc et nibh consectetur mattis. Etiam eu congue lectus, in lobortis ex. Cras maximus magna nec tempor hendrerit. Proin id accumsan justo, ut hendrerit massa. Sed eu sem turpis.\r\n        Aliquam sagittis, mauris at tristique placerat, libero est molestie nunc, sit amet rhoncus ligula urna vitae lectus. Duis vel ipsum pharetra, sodales justo sed, tincidunt leo. Fusce gravida porta sem, quis pulvinar odio ultrices id. \r\n        ', 
    2010, 
    64350, 
    'Essence', 
    'Automatique', 
    '143000', 
    'sources/annonces/Ferrari1.jpg', 
    'sources/annonces/Ferrari2.jpg', 
    'sources/annonces/Ferrari3.jpg', 
    'sources/annonces/Ferrari4.jpg', 
    'sources/annonces/Ferrari5.jpg'
),
(
    'Peugeot', 
    '3008', 
    '\r\n        Lorem ipsum dolor sit amet, \r\n        \r\n        consectetur adipiscing elit. Phasellus ut blandit enim. \r\n        Donec sagittis porttitor malesuada. Proin posuere ultrices mauris, \r\n        a feugiat nisl vehicula sit amet. Suspendisse quis imperdiet diam.\r\n        \r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        \r\n        eget auctor nibh. Praesent sed nunc et nibh consectetur mattis. Etiam eu congue lectus, in lobortis ex. Cras maximus magna nec tempor hendrerit. Proin id accumsan justo, ut hendrerit massa. Sed eu sem turpis.\r\n        Aliquam sagittis, mauris at tristique placerat, libero est molestie nunc, sit amet rhoncus ligula urna vitae lectus. Duis vel ipsum pharetra, sodales justo sed, tincidunt leo. Fusce gravida porta sem, quis pulvinar odio ultrices id. \r\n        ', 
    2018, 
    125330, 
    'Essence', 
    'Automatique', 
    '19500', 
    'sources/annonces/peugeot1.jpg', 
    'sources/annonces/peugeot2.jpg', 
    'sources/annonces/peugeot3.jpg', 
    '', 
    ''
),
(
    'Renault', 
    'Twingo', 
    '\r\n        Lorem ipsum dolor sit amet, \r\n        \r\n        consectetur adipiscing elit. Phasellus ut blandit enim. \r\n        Donec sagittis porttitor malesuada. Proin posuere ultrices mauris, \r\n        a feugiat nisl vehicula sit amet. Suspendisse quis imperdiet diam.\r\n        \r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n        nibh - auctor nibh\r\n\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        -Praesent\r\n        \r\n        eget auctor nibh. Praesent sed nunc et nibh consectetur mattis. Etiam eu congue lectus, in lobortis ex. Cras maximus magna nec tempor hendrerit. Proin id accumsan justo, ut hendrerit massa. Sed eu sem turpis.\r\n        Aliquam sagittis, mauris at tristique placerat, libero est molestie nunc, sit amet rhoncus ligula urna vitae lectus. Duis vel ipsum pharetra, sodales justo sed, tincidunt leo. Fusce gravida porta sem, quis pulvinar odio ultrices id. \r\n        ', 
    1999, 
    103000, 
    'Diesel', 
    'Manuelle', 
    '1900', 
    'sources/annonces/twingo1.jpg', 
    'sources/annonces/twingo2.jpg', 
    'sources/annonces/twingo3.jpg', 
    '', 
    ''
);


INSERT INTO contact_info (phone_number, e_mail) VALUES 
('+33 0 00 00 00 00', 'garageExemple@gmail.com');

INSERT INTO user (email, roles, password, is_verified) VALUES
('user1@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user2@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user3@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user4@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user5@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user6@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user7@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user8@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user9@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('user10@exemple.com', '[\"ROLE_USER\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('staff1@exemple.com', '[\"ROLE_STAFF\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('staff2@exemple.com', '[\"ROLE_STAFF\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('staff3@exemple.com', '[\"ROLE_STAFF\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1),
('admin@main.com', '[\"ROLE_ADMIN\"]', '$2y$10$6PglNv2kPoQfpNxs9Lovoe4vwAYd5v6R5Yq3.r1yHKLciNzW7Oobe', 1);

INSERT INTO reviews (user_mail_id, grade, review, was_moderated) VALUES
(1, 1, 'Exemple de commentaire', 1),
(2, 2, 'Exemple de commentaire', 1),
(3, 0, 'Exemple de commentaire', 1),
(4, 3, 'Exemple de commentaire', 1),
(5, 1, 'Exemple de commentaire', 1),
(6, 1, 'Exemple de commentaire', 1),
(7, 1, 'Exemple de commentaire', 1),
(8, 2, 'Exemple de commentaire', 1),
(9, 3, 'Exemple de commentaire', 1),
(10, 1, 'Exemple de commentaire', 1),
(11, 1, 'Exemple de commentaire', 1),
(12, 3, 'Exemple de commentaire', 1),
(13, 0, 'Exemple de commentaire', 1),
(14, 4, 'Exemple de commentaire', 1);

INSERT INTO services (title, description, price, img_path) VALUES
('Vidange', 'Vidange complète à prix fixe !', 25, 'sources/services/vidange.jpg'),
('Changement pneu', 'Profitez de notre offre du moment ! Seulement 10€ par pneu !', 10, 'sources/services/pneu.jpg'),
('Diagnostic suspension', 'Diagnostic complet des systèmes de suspension. Obtenez un devis personnalisé !', NULL, 'sources/services/suspension.jpg'),
('Remplissage AC', "Soyez prêt pour l'été, remplissage de l'AC à prix fixe !", 60, 'sources/services/ac.jpg'),
('Révision des freins', 'Révision complète des systèmes de freinage.', 253, 'sources/services/brakes.jpg'),
('Changement accumulateur', "Seulement 20€ pour l'installation de la batterie achetée dans notre garage !", 20, 'sources/services/batterie.jpg');

INSERT INTO working_hours (monday, tuesday, wednesday, thursday, friday, saturday, sunday) VALUES
('09:00-12:30 et 13:30-17:30', '09:00-12:30 et 13:30-17:30', '09:00-12:30 et 13:30-17:00', '09:00-12:30 et 13:30-17:30', '09:00-12:30 et 13:30-17:30', '09:00-12:30', 'Fermé');